package member;

//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
/*
 * DAO : Data Access Object  
 * 데이터 베이스에 접속해서 데이터 추가, 삭제, 수정 등의 작업을 하는 클래스
 */
import java.sql.*;//요렇게 시작하면 밑에꺼 안 불러와도 됨
import java.util.ArrayList;

public class ShoppingDAO {
	/*
	 * 1. 필드 = 멤버변수
	 */
	Connection con;// 기본값
	PreparedStatement ps;// 기본값
	ResultSet rs;// 기본값

	String sql = "";
	/*
	 * 2. 생성자 : 기본생성자-필드에 기본값(수:0, boolean:false, 클래스 타입:null)을 주어 객체 생성
	 */

	/*
	 * 3. 메서드
	 */
	public static Connection getConnection() throws Exception {
		/* 첫번째 방법 */
		// 1.오라클 드라이버 로딩
		Class.forName("oracle.jdbc.OracleDriver");

		// 2.Connection 객체 생성
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		Connection con = DriverManager.getConnection(url, "system", "1234");// 지역변수 : 반드시 초기화
		return con;
	}

//1.회원번호조회('회원등록' 폼에서) - 다음 번호 조회(단건조회) + 시스템으로부터 날짜
	public MemberBeans getMaxCustnoJoindate() throws Exception {
		MemberBeans beans = new MemberBeans();

		try {
			// 같은 클래스이므로 클래스이름 생략가능
			// 1.con:멤버변수 con
			con = getConnection();// static 메서드이므로 바로 호출 가능

			// 2.sql
			sql += "select NVL(max(custno),0)+1 AS custno,";
			sql += " to_char(sysdate,'yyyymmdd') as joindate";
			sql += " from member_tbl_02";

			// 3. 실행
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();// 이미 sql문을 가지고 컴파일한상태라 매개변수가 없음

			// 4. 결과처리 -> 최대회원번호+1, '오늘날짜'로 셋팅된 객체
			if (rs.next()) {
				beans.setCustno(rs.getString(1));
				beans.setJoindate(rs.getString(2));// beans.setCustno(rs.getString)
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5. DB 연결 해제위해서.
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return beans;
	}

	// 2.회원등록
	public void insertMember(MemberBeans beans) throws Exception {
		try {
			// 같은 클래스이므로 클래스이름 생략가능
			// 1. con: 멤버변수 con
			con = getConnection();// static 메서드이므로 바로 호출 가능

			// 2.sql

			// sql += "insert into
			// member_tbl_02(custno,custname,phone,address,joindate,gradee,city)
			// values(?,?,?,?,?,?,?)";
			sql += "insert into member_tbl_02 values(?,?,?,?,?,?,?)";
			// sql += "insert into member_tbl_02 values(?,?,?,?,to_char(?,'yyyy-mm-dd'),?)";

			// 3. 실행
			ps = con.prepareStatement(sql);
			ps.setString(1, beans.getCustno());
			ps.setString(2, beans.getCustname());
			ps.setString(3, beans.getPhone());
			ps.setString(4, beans.getAddress());
			ps.setString(5, beans.getJoindate());
			ps.setString(6, beans.getGrade());
			ps.setString(7, beans.getCity());

			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5. DB 연결 해제위해서.
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// 3. 회원전체조회
	public ArrayList<MemberBeans> getMembers() {
		ArrayList<MemberBeans> list = new ArrayList<MemberBeans>();
		try {
			// 같은 클래스이므로 클래스이름 생략가능
			// 1. con: 멤버변수 con
			con = getConnection();// static 메서드이므로 바로 호출 가능

			// 2.sql
			sql += "select custno, custname,phone,address,";
			sql += " to_char(joindate,'yyyy-mm-dd') as joindate,";
			sql += " decode(grade, 'A','VIP','B','일반','C','직원') as grade,";
			sql += " city";
			sql += " from member_tbl_02";

			// 3. 실행
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

			// 4.결과처리
			while (rs.next()) {
				MemberBeans beans = new MemberBeans();

				// 필드에 기본값이 아닌 결과셋의 레코드의 값들로 채움
				beans.setCustno(rs.getString(1));
				beans.setCustname(rs.getString(2));
				beans.setPhone(rs.getString(3));
				beans.setAddress(rs.getString(4));
				beans.setJoindate(rs.getString(5));
				beans.setGrade(rs.getString(6));
				beans.setCity(rs.getString(7));

				list.add(beans);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5. DB 연결 해제위해서.
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	// 4.회원조회- '회원번호(custno)를 매개값으로 받아 조회한 회원객체를 리턴
	public MemberBeans getMember(String custno) {// "100001"
		MemberBeans beans = new MemberBeans();// 기본값으로 채워진 객체
		try {
			// 같은 클래스이므로 클래스이름 생략가능
			// 1.con:멤버변수 con
			con = getConnection();// static 메서드이므로 바로 호출 가능

			// 2.sql
			sql += "select custno, custname,phone,address,";
			sql += " to_char(joindate,'yyyy-mm-dd') as joindate,";
			sql += " grade,";
			sql += " city";
			sql += " from member_tbl_02";
			sql += " where custno=?";

			// 3. 실행
			ps = con.prepareStatement(sql);
			ps.setString(1, custno);

			rs = ps.executeQuery();

			// 4. 결과처리 : 필드에 기본값이 아닌 결과셋에서 얻어온 값으로 변경
			if (rs.next()) {// 결과 1개여서 if문 씀
				beans.setCustno(rs.getString(1));
				beans.setCustname(rs.getString(2));
				beans.setPhone(rs.getString(3));
				beans.setAddress(rs.getString(4));
				beans.setJoindate(rs.getString(5));
				beans.setGrade(rs.getString(6));
				beans.setCity(rs.getString(7));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5. DB 연결 해제위해서.
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return beans;
	}

	// 5. 회원수정
	public void updateMember(MemberBeans beans) {
		// 1. con: 멤버변수 con
		try {
			con = getConnection();// static 메서드이므로 바로 호출 가능

			sql += "update member_tbl_02 set custno=?, custname=?, address=?, joindate=?, grade=?, city=? where custno = ?";
			ps = con.prepareStatement(sql);
			// 찾는거닌깐 7번까지 했어야된다

			ps.setString(1, beans.getCustno());
			ps.setString(2, beans.getCustname());
			ps.setString(3, beans.getPhone());
			ps.setString(4, beans.getAddress());
			ps.setString(5, beans.getJoindate());
			ps.setString(6, beans.getGrade());
			ps.setString(7, beans.getCity());

			ps.executeUpdate(); // 수정이닌깐 수정을 하고 다시 sql문에 던져줘야 저장이 되닌깐 ps.을사용
			// rs = ps.executeUpdate(); //안던져 주닌깐 안쓴다
		} catch (Exception e) {
			// TODO 자동 생성된 catch 블록
			e.printStackTrace();
		} finally {
			// 5. DB 연결 해제위해서.
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	// 6.회원삭제
	public void deleteMember(MemberBeans beans) {
		try {
			// 1. con: 멤버변수 con
			con = getConnection();// static 메서드이므로 바로 호출 가능

			// 2. SQL delete는
			sql = "delete from member_tbl_02 where custno = ?";

			// 3 SQL
			ps = con.prepareStatement(sql); // 이거 밑에 적어야 sql += 한걸 받아서 준다
			ps.setString(1, beans.getCustno());

			// rs = ps.executeQuery(); // 받고 그만
			ps.executeUpdate(); // 받고 던져줘야된다
		} catch (Exception e) {// static 메서드이므로 바로 호출 가능
			e.printStackTrace();
		} finally {
			// 5. DB 연결 해제위해서.
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// 7.매출전체조회(SaleBeans)
	public ArrayList<SalesBeans> getSalesBeans() {
		ArrayList<SalesBeans> list = new ArrayList<SalesBeans>();
		try {
			// 같은 클래스이므로 클래스이름 생략가능
			// 1. con: 멤버변수 con
			con = getConnection();// static 메서드이므로 바로 호출 가능

			// 2.sql
			sql += "select custno, custname, decode(grade, 'A','VIP','B','일반','C','직원') as grade, sum(price) as price";
			sql += " from member_tbl_02 natural join money_tbl_02";
			sql += " group by custno, custname, grade";
			sql += " order by price desc";

			// 3. 실행
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

			// 4.결과처리
			while (rs.next()) {
				SalesBeans sale = new SalesBeans();

				// 필드에 기본값이 아닌 결과셋의 레코드의 값들로 채움
				sale.setCustno(rs.getString(1));
				sale.setCustname(rs.getString(2));
				sale.setGrade(rs.getString(3));
				sale.setTotalprice(rs.getString(4));

				list.add(sale);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5. DB 연결 해제위해서.
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}
}
