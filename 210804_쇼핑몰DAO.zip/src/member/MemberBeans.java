/* 디자이너와 프로그래머가 협업하여 개발함
 * 자바빈은 jsp 페이지의 디자인 부분과 비지니스 로직 로직(=자바코드) 부분을 
 * 분리함으로써 복잡한 jsp 코드들을 줄이고 프로그램을 재사용성을 증가시킨다.
 * DTO(Data Transfer Object)
 * DAO(Data Access Object) 클래스로 접근하여 DB로부터 가져온 내용을 객체로 바꾸기 위해 필요한 클래스
 * => 자바빈
 * 책 247p 자바빈의 설계규약 참조
 */

//회원목록조회
package member;
public class MemberBeans {
	//1.멤버변수 - private (sql 테이블 컬럼이랑 똑같은 이름으로 해야함)
	String custno;
	String custname;
	String phone;
	String address;
	String joindate;
	String grade;
	String city;
	
	//2.매개변수 없는 기본 생성자 필요(안 만들어도 됨)
	
	//3.메서드 - public
	public String getCustno() {
		return custno;
	}
	public void setCustno(String custno) {
		this.custno = custno;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getJoindate() {
		return joindate;
	}
	public void setJoindate(String joindate) {
		this.joindate = joindate;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	
	
	
}
